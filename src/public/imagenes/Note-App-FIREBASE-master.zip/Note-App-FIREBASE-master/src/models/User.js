const { createUserWithEmailAndPassword, getAuth } = require('firebase/auth');
const { app } = require('../database');

const auth = getAuth(app);

// Función para registrar un nuevo usuario
const signup = async (req, res) => {
  const { email, password } = req.body;

  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Usuario registrado con éxito
    res.status(201).json({ message: 'Usuario registrado con éxito', user });
  } catch (error) {
    console.error('Error al registrar el usuario:', error);
    res.status(500).json({ error: 'Hubo un error al registrar el usuario' });
  }
};

module.exports = { signup };
