const passport = require('passport');
const { getAuth } = require('firebase/auth');
const { app } = require('../database');

const auth = getAuth(app);

passport.serializeUser((user, done) => {
  done(null, user.uid); // Usar el UID de Firebase como identificador
});

passport.deserializeUser(async (uid, done) => {
  try {
    // Puedes utilizar Firebase Authentication para obtener información adicional del usuario si es necesario
    // Esto dependerá de la estructura de datos almacenada en Firebase Authentication
    // Por ejemplo, si Firebase almacena el nombre del usuario, puedes hacer algo como:
    const user = {
      uid: uid,
      name: 'Nombre de usuario obtenido de Firebase', // Reemplaza con la lógica real para obtener el nombre
      // Otros campos que desees recuperar
    };
    done(null, user);
  } catch (error) {
    done(error, null);
  }
});

module.exports = passport;
