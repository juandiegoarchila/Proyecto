const { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } = require('firebase/auth');
const { db } = require('../database');
const { collection, addDoc } = require('firebase/firestore');
const { app } = require('../database');

const auth = getAuth(app);

const userCtrl = {};

userCtrl.rendersigUnForm = (req, res) => {
  res.render('users/signup', { name: req.body.name });
};

userCtrl.signup = async (req, res) => {
  const { name, email, password, confirm_password } = req.body;

  try {
    // Comprueba si el usuario ya está autenticado
    if (req.isAuthenticated()) {
      req.flash('error_msg', 'Ya estás autenticado. Cierra sesión antes de registrarte nuevamente.');
      return res.redirect('/notes'); // Puedes redirigir a otra página
    }

    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    const userData = {
      name,
      email,
      // Puedes agregar más campos aquí si lo deseas
    };

    // Agregar datos del usuario a Firestore
    const docRef = await addDoc(collection(db, 'users'), userData);

    req.flash('success_msg', '¡Ya estás registrado!');
    res.redirect('/users/signin');
  } catch (error) {
    console.error('Error al registrar el usuario:', error);
    req.flash('error_msg', 'Hubo un error al registrar el usuario');
    res.redirect('/users/signup');
  }
};

userCtrl.rendersigninForm = (req, res) => {
  res.render('users/signin', { user: req.user });
};

userCtrl.signin = async (req, res) => {
  const { email, password } = req.body;

  try {
    // Comprueba si el usuario ya está autenticado
    if (req.isAuthenticated()) {
      req.flash('error_msg', 'Ya estás autenticado. Cierra sesión antes de iniciar sesión nuevamente.');
      return res.redirect('/notes'); // Puedes redirigir a otra página si lo deseas
    }

    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    req.flash('success_msg', '¡Has iniciado sesión exitosamente!');
    
    // Aquí obtén la información del usuario autenticado
    const user = userCredential.user;
    
    // Renderiza la vista "notes" en la que deseas mostrar la información del usuario
    res.render('notes/all-notes', { user }); // Ajusta la ruta de la vista según tu estructura de carpetas

  } catch (error) {
    req.flash('error_msg', 'Credenciales inválidas, inténtalo de nuevo');
    res.redirect('/users/signin');
  }
};


userCtrl.logout = (req, res) => {
  signOut(auth)
    .then(() => {
      req.flash('success_msg', 'Sesión cerrada');
      res.redirect('/users/signin');
    })
    .catch((error) => {
      req.flash('error_msg', 'Hubo un error al cerrar la sesión');
      res.redirect('/notes');
    });
};

module.exports = userCtrl;
