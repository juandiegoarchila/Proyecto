const { db } = require('../database');
const { collection, addDoc, getDocs, doc, updateDoc, deleteDoc, getDoc } = require('firebase/firestore');
const Note = require("../models/Note");

const notesCtrl = {};

// Renderiza el formulario para crear una nueva nota
notesCtrl.renderNoteform = (req, res) => {
  res.render("notes/new-note", { user: req.user });
};

// Crea una nueva nota en Firestore
notesCtrl.createNewnote = async (req, res) => {
  const { title, description } = req.body;
  const newNote = {
    title,
    description,
    user: req.user.uid,
  };

  try {
    const docRef = await addDoc(collection(db, 'notes'), newNote);
    req.flash('success_msg', 'Nota agregada exitosamente');
    res.redirect('/notes');
  } catch (error) {
    console.error('Error al crear una nueva nota:', error);
    req.flash('error_msg', 'Error al crear una nueva nota');
    res.redirect('/notes');
  }
};

// Renderiza todas las notas del usuario actual
notesCtrl.renderNotes = async (req, res) => {
  try {
    const querySnapshot = await getDocs(collection(db, 'notes'));
    const notes = [];
    querySnapshot.forEach((doc) => {
      const note = {
        id: doc.id,
        ...doc.data(),
      };
      if (note.user === req.user.uid) {
        notes.push(note);
      }
    });
    res.render('notes/all-notes', { notes, user: req.user });
  } catch (error) {
    console.error('Error al obtener las notas:', error);
    req.flash('error_msg', 'Error al obtener las notas');
    res.redirect('/notes');
  }
};

// Renderiza el formulario de edición de una nota
notesCtrl.renderEditForm = async (req, res) => {
  try {
    const noteId = req.params.id;
    const noteRef = doc(db, 'notes', noteId);
    const noteSnapshot = await getDoc(noteRef);

    if (!noteSnapshot.exists()) {
      req.flash('error_msg', 'No autorizado');
      res.redirect('/notes');
      return;
    }

    const noteData = noteSnapshot.data();

    if (noteData.user !== req.user.uid) {
      req.flash('error_msg', 'No autorizado');
      res.redirect('/notes');
    } else {
      res.render('notes/edit-note', { note: { id: noteId, ...noteData } });
    }
  } catch (error) {
    console.error('Error al renderizar el formulario de edición:', error);
    req.flash('error_msg', 'Error al renderizar el formulario de edición');
    res.redirect('/notes');
  }
};

// Actualiza una nota en Firestore
notesCtrl.updateNote = async (req, res) => {
  const noteId = req.params.id;
  const { title, description } = req.body;
  const noteRef = doc(db, 'notes', noteId);

  try {
    await updateDoc(noteRef, {
      title,
      description,
    });
    req.flash('success_msg', 'Nota actualizada exitosamente');
    res.redirect('/notes');
  } catch (error) {
    console.error('Error al actualizar la nota:', error);
    req.flash('error_msg', 'Error al actualizar la nota');
    res.redirect('/notes');
  }
};

// Elimina una nota de Firestore
notesCtrl.deletenote = async (req, res) => {
  const noteId = req.params.id;
  const noteRef = doc(db, 'notes', noteId);

  try {
    await deleteDoc(noteRef);
    req.flash('success_msg', 'Nota eliminada exitosamente');
    res.redirect('/notes');
  } catch (error) {
    console.error('Error al eliminar la nota:', error);
    req.flash('error_msg', 'Error al eliminar la nota');
    res.redirect('/notes');
  }
};

module.exports = notesCtrl;
