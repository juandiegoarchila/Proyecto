module.exports = {
  isAuthenticated: function(req, res, next) {
    // Si deseas quitar la comprobación de autenticación, simplemente llama a next()
    next();
  },
};
